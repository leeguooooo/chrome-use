// Browser-level tab liveness helpers. Keeping them free of `chrome.*` globals
// makes the service-worker recovery rules unit-testable.

/** Resolve the first browser-level tab that still exists. */
export async function resolveFirstLiveTab(candidateIds, getTab) {
  const seen = new Set()
  for (const tabId of candidateIds) {
    if (tabId == null || seen.has(tabId)) continue
    seen.add(tabId)
    const tab = await getTab(tabId).catch(() => null)
    if (tab) return { tabId, tab }
  }
  return null
}

/**
 * Split attached relay records into live entries and confirmed dead records.
 * A tab is dead when `deps.getTab` answers without it, or fails with an error
 * `deps.isMissing(error, tabId)` accepts (Chrome's own "No tab with id").
 * Without `isMissing` every failed read counts as dead (the #196 rule); with
 * it, any other failure keeps the entry, since it proves nothing.
 */
export async function reconcileAttachedTabEntries(entries, deps) {
  const live = []
  const removed = []
  for (const [tabId, entry] of entries) {
    let tab = null
    try {
      tab = await deps.getTab(tabId)
    } catch (error) {
      if (deps.isMissing && !deps.isMissing(error, tabId)) tab = { id: tabId, unread: true }
    }
    if (tab) {
      live.push([tabId, entry])
      continue
    }
    deps.detach(tabId)
    deps.unmarkOwned(tabId)
    removed.push({ tabId, targetId: entry.targetId, sessionId: entry.sessionId })
  }
  return { live, removed }
}

/** Prefer a recovered session alias to the tab id encoded before replacement. */
export function resolveSessionTab(sessionId, mainSessions, childSessions) {
  const mapped = mainSessions.get(sessionId) ?? childSessions.get(sessionId)
  if (mapped != null) return mapped
  const encoded = /^cb-tab-(\d+)$/.exec(sessionId || '')
  return encoded ? Number(encoded[1]) : null
}

/** Remove every alias of a detached tab without disturbing other sessions. */
export function forgetSessionTab(sessionMap, tabId) {
  for (const [sessionId, mappedTabId] of sessionMap) {
    if (mappedTabId === tabId) sessionMap.delete(sessionId)
  }
}
